# Banhammer für Purpur / Minecraft 26.1.2

Dieses Paket enthält den **Quellcode** für das Plugin-Projekt. Es enthält noch keine kompilierte JAR-Datei.

## Funktion
- `/banhammer` gibt dem ausführenden Admin den Hammer.
- `/banhammer give <Spieler>` gibt ihn einem online Spieler.
- Ein Treffer mit dem markierten Netherite-Axt-Item löst einen rein visuellen Blitz, Partikel und Donner aus und bannt den Spieler permanent anhand des Namens.
- Normalschaden wird verhindert; der Blitz-Effekt setzt das Ziel nicht in Brand.
- `banhammer.give` und `banhammer.use` sind standardmäßig OP-only.

## Bauen
Minecraft 26.1.x benötigt Java 25. Installiere JDK 25 und Gradle 8.14 oder eine kompatible neuere Gradle-Version. Öffne ein Terminal in diesem Ordner und führe aus:

    gradle build

Die fertige Datei sollte anschließend unter `build/libs/Banhammer-1.0.0.jar` liegen.

## Installieren
1. Server stoppen.
2. `Banhammer-1.0.0.jar` in den Serverordner `plugins/` kopieren.
3. Server starten und im Log prüfen, ob `Banhammer enabled` erscheint.
4. Als OP `/banhammer` eingeben.
5. Erst auf einem Testserver ausprobieren. Entbannen: `/pardon Spielername` in der Konsole.

## Hinweise
- Das Projekt wurde hier nicht kompiliert oder auf einem laufenden Server getestet.
- Die API-Abhängigkeit verwendet `26.1.2.build.+`, passend zur 26.1.2-API-Linie. Falls Gradle keine passende API-Version findet, muss die Abhängigkeit auf einen tatsächlich verfügbaren Build festgesetzt werden.
- Der Bann ist permanent und namensbasiert, nicht IP-basiert.
