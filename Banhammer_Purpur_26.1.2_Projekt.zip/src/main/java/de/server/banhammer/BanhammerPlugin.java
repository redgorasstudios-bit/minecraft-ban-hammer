package de.server.banhammer;

import org.bukkit.BanList;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Arrays;
import java.util.Date;

public final class BanhammerPlugin extends JavaPlugin implements Listener {
    private NamespacedKey hammerKey;

    @Override
    public void onEnable() {
        hammerKey = new NamespacedKey(this, "banhammer");
        Bukkit.getPluginManager().registerEvents(this, this);
        getLogger().info("Banhammer enabled.");
    }

    private ItemStack createHammer() {
        ItemStack item = new ItemStack(Material.NETHERITE_AXE);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(ChatColor.DARK_RED.toString() + ChatColor.BOLD + "BANHAMMER");
        meta.setLore(Arrays.asList(
                ChatColor.GRAY + "Ein Treffer. Ein Blitz.",
                ChatColor.RED + "Bannt Spieler permanent.",
                ChatColor.DARK_PURPLE + "Nur fuer Admins"
        ));
        meta.getPersistentDataContainer().set(hammerKey, PersistentDataType.BYTE, (byte) 1);
        item.setItemMeta(meta);
        return item;
    }

    private boolean isHammer(ItemStack item) {
        if (item == null || item.getType() != Material.NETHERITE_AXE || !item.hasItemMeta()) {
            return false;
        }
        Byte marker = item.getItemMeta().getPersistentDataContainer()
                .get(hammerKey, PersistentDataType.BYTE);
        return marker != null && marker == (byte) 1;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!command.getName().equalsIgnoreCase("banhammer")) return false;
        if (!sender.hasPermission("banhammer.give")) {
            sender.sendMessage(ChatColor.RED + "Dazu hast du keine Berechtigung.");
            return true;
        }

        Player recipient;
        if (args.length == 2 && args[0].equalsIgnoreCase("give")) {
            recipient = Bukkit.getPlayerExact(args[1]);
            if (recipient == null) {
                sender.sendMessage(ChatColor.RED + "Dieser Spieler ist nicht online.");
                return true;
            }
        } else if (args.length == 0) {
            if (!(sender instanceof Player)) {
                sender.sendMessage("Benutzung: /banhammer give <Spieler>");
                return true;
            }
            recipient = (Player) sender;
        } else {
            sender.sendMessage(ChatColor.YELLOW + "Benutzung: /banhammer oder /banhammer give <Spieler>");
            return true;
        }

        recipient.getInventory().addItem(createHammer()).values()
                .forEach(item -> recipient.getWorld().dropItemNaturally(recipient.getLocation(), item));
        recipient.sendMessage(ChatColor.DARK_RED.toString() + ChatColor.BOLD + "Du hast den BANHAMMER erhalten!");
        if (!recipient.equals(sender)) {
            sender.sendMessage(ChatColor.GREEN + "Banhammer an " + recipient.getName() + " gegeben.");
        }
        return true;
    }

    @EventHandler
    public void onPlayerHit(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player)) return;
        if (!(event.getEntity() instanceof Player)) return;

        Player attacker = (Player) event.getDamager();
        Player target = (Player) event.getEntity();

        if (!isHammer(attacker.getInventory().getItemInMainHand())) return;
        if (!attacker.hasPermission("banhammer.use")) {
            attacker.sendMessage(ChatColor.RED + "Du darfst den Banhammer nicht benutzen.");
            event.setCancelled(true);
            return;
        }
        if (attacker.getUniqueId().equals(target.getUniqueId())) return;

        event.setCancelled(true);
        Location loc = target.getLocation();
        World world = target.getWorld();

        world.strikeLightningEffect(loc);
        world.spawnParticle(Particle.DRAGON_BREATH, loc.clone().add(0, 1, 0), 45, 0.55, 0.8, 0.55, 0.02);
        world.spawnParticle(Particle.CRIT, loc.clone().add(0, 1, 0), 35, 0.5, 0.7, 0.5, 0.2);
        world.playSound(loc, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 1.0f, 0.8f);

        String reason = "Vom Banhammer getroffen.";
        Bukkit.getBanList(BanList.Type.NAME).addBan(target.getName(), reason, (Date) null, attacker.getName());
        target.kickPlayer(ChatColor.DARK_RED + "Du wurdest vom BANHAMMER gebannt!\n"
                + ChatColor.GRAY + "Grund: " + reason);
        Bukkit.broadcastMessage(ChatColor.DARK_RED.toString() + ChatColor.BOLD + target.getName()
                + ChatColor.RED + " wurde vom Banhammer von " + attacker.getName() + " gebannt!");
        getLogger().info(target.getName() + " was banned by " + attacker.getName() + " using the Banhammer.");
    }
}
